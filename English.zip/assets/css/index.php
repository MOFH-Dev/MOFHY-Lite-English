<?php
	header('location: ../');
?>